from selenium import webdriver
from pageObjects.LoginPage import LoginDetails


class Test_02_login:

    baseurl = "https://www.goibibo.com"
    city_one = "Mumbai, India (BOM)"
    city_two = "New Delhi, India (DEL)"


    def test_loginToPage(self, commonStuff):
        self.driver = commonStuff
        self.driver.get(self.baseurl)
        self.driver.maximize_window()
        self.p = LoginDetails(self.driver)
        self.p.oneWay()
        self.p.enter_fisrt_city(self.city_one)
