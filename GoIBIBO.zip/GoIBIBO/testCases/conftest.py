import pytest
from selenium import  webdriver

@pytest.fixture()
def commonStuff():
    driver= webdriver.Chrome(executable_path=r'C:\Users\srd18\Downloads\chromedriver_win32\chromedriver.exe' )
    return driver