from selenium import webdriver

class LoginDetails:

    oneWay_xpath = '//span[@class="sc-gsNilK dImRia"]'
    enter_city_path = '//p[@class = "sc-iJKOTD iipKRx fswWidgetPlaceholder"]//parent::div[@class = "sc-hiCibw dGZLZw"]//parent::div[@class = "sc-jJoQJp iPfLQ"]'

    def __init__(self, driver):
        self.driver = driver

    def oneWay(self):
        self.driver.find_element_by_xpath(self.oneWay_xpath).click()

    def enter_fisrt_city(self,firstCity):
        self.driver.find_element_by_xpath(self.enter_city_path).click()
        self.driver.find_element_by_xpath(self.enter_city_path).send_keys(firstCity)