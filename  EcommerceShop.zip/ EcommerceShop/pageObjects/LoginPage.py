import time

class LoginHere:
    signinUrl_xpath = '//a[text() = "Sign in"]'
    username_textbox_id = "userid"
    continue_button = "signin-continue-btn"
    password_textbox_id = "pass"
    complete_login_id = "sgnBt"
    searchbox_xpath = '//input[@class = "gh-tb ui-autocomplete-input" and @id="gh-ac"]'
    searchBtn_id = "gh-btn"
    mayBeLater_xpath = '//button[@id = "webauthn-maybe-later-link"]'
    itemName_xpath = '//h3[text() = "39 Colors All in one Makeup Kit Eyeshadow Palette Lip Gloss Blush Cosmetic Set"]'
    addToCart_id = '//a[@id = "isCartBtn_btn"]'

    def __init__(self,driver):
        self.driver= driver

    def clickSignin(self):
        self.driver.find_element_by_xpath(self.signinUrl_xpath).click()

    def enterUsername(self,usrname):
        self.driver.find_element_by_id(self.username_textbox_id).click()
        self.driver.find_element_by_id(self.username_textbox_id).send_keys(usrname)

    def nxtToPasswd(self):
        self.driver.find_element_by_id(self.continue_button).click()

    def enterPassword(self,password):
        self.driver.find_element_by_id(self.password_textbox_id).click()
        self.driver.find_element_by_id(self.password_textbox_id).send_keys(password)

    def sucessfulLoginBtn(self):
        self.driver.find_element_by_id(self.complete_login_id).click()
        time.sleep(2)
        self.driver.find_element_by_xpath(self.mayBeLater_xpath).click()

    def searchItem(self):
        self.driver.find_element_by_xpath(self.searchbox_xpath).click()
        self.driver.find_element_by_xpath(self.searchbox_xpath).send_keys("Makeup-kit")
        time.sleep(2)
        self.driver.find_element_by_id(self.searchBtn_id).click()

    def item_view_and_add_to_cart(self):
        self.driver.find_element_by_xpath(self.itemName_xpath).click()
        time.sleep(10)
        self.driver.find_element_by_id(self.addToCart_id).click()