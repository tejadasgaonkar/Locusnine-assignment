import time
import pytest
from selenium import webdriver
from pageObjects.LoginPage import LoginHere

class Test_01_login:
    baseurl = "https://www.ebay.com"
    username = "tejadasgaonkar@gmail.com"
    password = "Ebay27May2022"

    def test_loginToPage(self, commonStuff):
        self.driver = commonStuff
        self.driver.get(self.baseurl)
        time.sleep(2)
        self.p = LoginHere(self.driver)
        self.p.clickSignin()
        self.p.enterUsername(self.username)
        self.p.nxtToPasswd()
        time.sleep(2)
        self.p.enterPassword(self.password)
        self.p.sucessfulLoginBtn()
        self.p.searchItem()
        self.p.item_view_and_add_to_cart()



